<!-- ======= Call To Action Section ======= -->
<section id="call-to-action" class="call-to-action">
          <div class="container text-center" data-aos="zoom-out">
            <a href="https://www.youtube.com/watch?v=V0kvqSUbta4&ab_channel=AdoptDon%27tShop" class="glightbox play-btn"></a>
            <h3>Adote, não compre!</h3>
            <p> 
            Em nosso site de adoção, abraçamos a filosofia 'Adote, não compre' com todo o nosso coração. Acreditamos firmemente que a adoção é a maneira mais gratificante de trazer um novo membro peludo para a sua família.Ao escolher a adoção, você não apenas salva uma vida, mas também ajuda a combater o problema da superpopulação animal e a interromper o comércio de animais de criação em larga escala.
            </p>
            <a class="cta-btn" href="#portfolio">Adote, não compre!</a>
          </div>
        </section><!-- End Call To Action Section -->